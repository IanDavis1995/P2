package org.moire.opensudoku.gui.exporting;

import java.io.File;

public class FileExportTaskResult {
	public boolean successful;
	public File file;
	public String error;
}
